
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
    <meta name="description" content="">
    <meta name="author" content="">

    <title>HiFood Order</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../../assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="starter-template.css" rel="stylesheet">

	

		<style>
		body {
              padding-top: 50px;}
              .starter-template {
              padding: 40px 15px;
              text-align: center;}
	    </style>
  </head>

<?php
  session_start();
  if(!isset($_SESSION["sess_user"])){
          header("location:login.php");
  } else {
  ?>
<body>

  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">HiFood</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="toplist.php">Top List</a></li>
            <li><a href="prepare.php">Prepare Me</a></li>
            <li><a href="order.php">Order</a></li>
            <li><a href="direction.php">Direction</a></li>
			      <li><a href="contact.php">Contact Us</a></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>


    <div class="container">
    
        <div class="starter-template">
          <h1>Welcome "<?=$_SESSION['sess_user'];?>"</h1>
          <p class="lead">Let the HiFood find your favorite foods</p>
        </div>

<div class="container">
    <div class="row">
 
      <div class="col-md-offset-3 col-md-6 col-sm-offset-2 col-sm-8">
          <div class="header-thumb">
              <h1 class="wow fadeIn" data-wow-delay="1.6s">Top List</h1> 
              <h3 class="wow fadeInUp" data-wow-delay="1.9s">Here are some recommened restaurant for you</h3>
          </div>
      </div>

    </div>
    
  <div class="panel-group iso-section wow fadeInUp" data-wow-delay="2.6s" id="accordion">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Restaurant one</a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse in">
        <div class="iframe-wrap panel-body">
            <iframe src="https://www.google.com/maps/dir/Blackrock,+Co.+Dublin,+Ireland/Pigeon+House+Rd,+Dublin+4,+Ireland/@53.322868,-6.20851,17604m/data=!3m1!1e3!4m14!4m13!1m5!1m1!1s0x486708c0d4a91e95:0x2600c7a819b930f1!2m2!1d-6.1770667!2d53.300791!1m5!1m1!1s0x48670ee3ff80048d:0xf397624799228dfb!2m2!1d-6.217121!2d53.3430259!3e1?hl=en-IE" height=300p></iframe>
        </div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Restaurant two</a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <div class="iframe-wrap panel-body">
          <iframe src="https://www.google.com/maps/embed?pb=!1m29!1m12!1m3!1d76095.08234716694!2d-6.19080908256662!3d53.41533775805504!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m14!1i0!3e1!4m5!1s0x48671a861546849d%3A0xb788e35e29569f31!2sMalahide+Castle%2C+Ireland!3m2!1d53.444933999999996!2d-6.164568999999999!4m5!1s0x486704e16bbccb97%3A0xa00c7a997317110!2sHowth%2C+Ireland!3m2!1d53.3858469!2d-6.0646843!5e1!3m2!1sen!2s!4v1429048216960">
        </iframe>
      </div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Restaurant three</a>
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <div class="iframe-wrap panel-body">
          <iframe src="https://www.google.com/maps/embed?pb=!1m29!1m12!1m3!1d38137.10711614389!2d-6.300614411168963!3d53.31515997194591!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m14!1i0!3e1!4m5!1s0x48670eb4d4cc2c25%3A0xeea6d3daaad01f63!2sDavid+Lloyd+Riverview+Sports+%26+Leisure%2C+Dublin%2C+Ireland!3m2!1d53.314811999999996!2d-6.234952!4m5!1s0x48670b8e504e0843%3A0xff9f8af03acf24f8!2sBushy+Park%2C+Terenure%2C+Dublin%2C+Ireland!3m2!1d53.302417999999996!2d-6.296399999999999!5e1!3m2!1sen!2s!4v1429048295498">
          </iframe>
       </div>
      </div>
    </div>
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">Restaurant four</a>
        </h4>
      </div>
      <div id="collapse4" class="panel-collapse collapse">
        <div class="iframe-wrap panel-body">
          <iframe width="600" height="450" frameborder="0" style="border:0"
src="https://www.google.com/maps/embed/v1/directions?origin=place_id:ChIJ55du2IwOZ0gRNal_7nS3UW0&destination=place_id:ChIJ-Tf6_IIOZ0gR4WvW49ZFp8I&key=AIzaSyBAOZuMVDCpaCDF4xgNmmEhduOEZQiAhCM" allowfullscreen></iframe>
       </div>
      </div>
    </div>
  </div> 
</div>


  </body>
  	   
	
  <div class="container"> <!--footer-->
    <hr>
  <footer>
    <div class="row">
      <div class="col-lg-12">
        <p>Copyright 2017 &copy; Hifood ltd </p>
      </div>
    </div>
  </footer>
  </div><!--Footer-->
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>
  </body>
</html>

  <?php
  }
  ?>